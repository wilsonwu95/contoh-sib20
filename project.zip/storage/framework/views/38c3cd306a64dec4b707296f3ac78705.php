<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>

	<?php $__errorArgs = ["error"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	<h3 style="color:red"><?php echo e($message); ?></h3>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	<form method="POST" action="<?php echo e(url('/login')); ?>">
		<?php echo csrf_field(); ?>
		<div>
			<label>Email</label>
			<input type="email" name="email" id="email">
		</div>
		<div>
			<label>Password</label>
			<input type="password" name="password" id="password">
		</div>
		<button type="submit">Submit</button>
	</form>
</body>
</html><?php /**PATH D:\xampp\htdocs\time\sib20\resources\views/auth/login.blade.php ENDPATH**/ ?>