<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Homepage</title>
</head>
<body>

	<h1>INI ADALAH HOMEPAGE</h1>

	<p><?php echo e($dataText); ?></p>
</body>
</html><?php /**PATH D:\xampp\htdocs\time\sib20\resources\views/homepage.blade.php ENDPATH**/ ?>