<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Form Edit Transaction</title>
	<script type="text/javascript" src="<?php echo e(asset('jquery-3.7.1.min.js')); ?>"></script>
</head>
<body>

	<form method="POST" action="<?php echo e(url('/transactions/edit')); ?>">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="id" id="id" value="<?php echo e($data->id); ?>">
		<div id="header">
			<div>
				<label>Invoice</label>
				<input type="text" name="invoice" id="invoice" value="<?php echo e($data->invoice); ?>">
			</div>
			<div>
				<label>Date</label>
				<input type="date" name="date" id="date" value="<?php echo e(date('Y-m-d', strtotime($data->date))); ?>">
			</div>
		</div>
		<div id="product-list">
			<button type="button" id="btn-add">Add Product</button>
			<table>
				<thead>
					<tr>
						<th>Product</th>
						<th>Qty</th>
						<th>Price</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="product-list-detail">
					<?php $__currentLoopData = $data->TransDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transDet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td>
							<select class="product_id" name="product_id[]">
								<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($p->id); ?>" data-price="<?php echo e($p->price); ?>"
									<?php if($p->id == $transDet->products_id): ?>
									selected
									<?php endif; ?>
									>
									<?php echo e($p->product_name); ?>

								</option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>

							<input type="hidden" class="price_product" name="price[]" value="<?php echo e($transDet->price); ?>">
						</td>


						<td>
							<input type="number" class="qty" name="qty[]" min="1" value="<?php echo e($transDet->qty); ?>">
						</td>
						<td class="price">
							<?php echo e($transDet->qty * $transDet->price); ?>

						</td>
						<td>
							<button type="button" class="btn-remove">Remove</button>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<button type="submit">Submit</button>
	</form>

</body>

<script type="text/javascript">
	$("#btn-add").click(function(e) {
		$.ajax({
			url: "<?php echo e(url('/product/get-row')); ?>",
			type: "GET",
			success: function(result) {
				$("#product-list-detail").append(result);
			},
			error: function(result) {
				alert(result.resultText);
			}
		});
	});

	$("#product-list-detail").on('click', '.btn-remove', function(e) {
		$(this).closest('tr').remove();
	});

	$("#product-list-detail").on('change', '.product_id', function(e) {
		var temp = $(this).find('option:selected').data('price');
		$(this).closest('td').find('input').val(temp);
		calculatePrice($(this));
	});


	$("#product-list-detail").on('change', '.qty', function(e) {
		calculatePrice($(this));
	});

	function calculatePrice(element) {
		var price = $(element).closest('tr').find('.price_product').val();
		var qty = $(element).closest('tr').find('.qty').val();

		var total = parseInt(price) * parseInt(qty);

		$(element).closest('tr').find('.price').text(total);
	}

</script>
</html><?php /**PATH D:\xampp\htdocs\time\sib20\resources\views/transactions/edit.blade.php ENDPATH**/ ?>