<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Product</title>
</head>
<body>
	<form method="POST" action="<?php echo e(url('/product/edit')); ?>">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="id" id="id" value="<?php echo e($data->id); ?>">
		<div>
			<label>Product Code</label>
			<input type="text" name="product_code" id="product_code" value="<?php echo e($data->product_code); ?>">
		</div>

		<div>
			<label>Product Name</label>
			<input type="text" name="product_name" id="product_name" value="<?php echo e($data->product_name); ?>">
		</div>

		<div>
			<label>Category</label>
			<select name="category_id" id="category_id">
				<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $data->category_id): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>

		<div>
			<label>Price</label>
			<input type="number" name="price" id="price" value="<?php echo e($data->price); ?>">
		</div>

		<div>
			<label>Description</label>
			<textarea name="description" id="description">
				<?php echo e($data->description); ?>

			</textarea>
		</div>

		<div>
			<label>Status</label>
			<select name="status" id="status">
				<option value="1" <?php if($data->status == 1): ?> selected <?php endif; ?>>Active</option>
				<option value="0" <?php if($data->status == 0): ?> selected <?php endif; ?>>Not Active</option>
			</select>
		</div>
		<button type="submit">Submit</button>
	</form>
</body>
</html><?php /**PATH D:\xampp\htdocs\time\sib20\resources\views/product/edit.blade.php ENDPATH**/ ?>