<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Product</title>
</head>
<body>
	<a href="<?php echo e(url('/logout')); ?>">Logout</a>
	
	<form method="GET" action="<?php echo e(url('/product')); ?>">
		<div>
			<label>Search</label>
			<input type="text" name="search" id="search">
		</div>
		<button type="submit">Submit</button>
	</form>

	<a href="<?php echo e(url('/product/add')); ?>">Tambah Data</a>
	<table border="1">
		<thead>
			<th>Code</th>
			<th>Name</th>
			<th>Category</th>
			<th>Price</th>
			<th>Desc.</th>
			<th>Status</th>
			<th>Action</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($dt->product_code); ?></td>
				<td><?php echo e($dt->product_name); ?></td>
				<td><?php echo e($dt->Category->name); ?></td>
				<td><?php echo e($dt->price); ?></td>
				<td><?php echo e($dt->description); ?></td>
				<td>
					<?php if($dt->status == 1): ?>
					Aktif
					<?php else: ?>
					Tidak Aktif
					<?php endif; ?>
				</td>
				<td>
					<a href="<?php echo e(url('/product/edit') . '/' . $dt->id); ?>">Edit</a>
					<a href="<?php echo e(url('/product/delete') . '/' . $dt->id); ?>">Delete</a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo e($data->links()); ?>

</body>
</html><?php /**PATH D:\xampp\htdocs\time\sib20\resources\views/product/view.blade.php ENDPATH**/ ?>