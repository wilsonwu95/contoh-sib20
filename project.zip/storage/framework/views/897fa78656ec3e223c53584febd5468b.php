<tr>
	<td>
		<select class="product_id" name="product_id[]">
			<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($p->id); ?>" data-price="<?php echo e($p->price); ?>"><?php echo e($p->product_name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<input type="hidden" class="price_product" name="price[]" value="<?php echo e($product[0]->price); ?>">
	</td>


	<td>
		<input type="number" class="qty" name="qty[]" min="1" value="1">
	</td>
	<td class="price">
		<?php echo e($product[0]->price); ?>

	</td>
	<td>
		<button type="button" class="btn-remove">Remove</button>
	</td>
</tr><?php /**PATH D:\xampp\htdocs\time\sib20\resources\views/product/row.blade.php ENDPATH**/ ?>